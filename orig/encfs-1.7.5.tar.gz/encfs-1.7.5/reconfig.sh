#!/bin/sh
autoreconf -i

